=== Auto Load Post on Scroll ===
Plugin Name: Lazy Loader
Plugin URI: http://inmaxsys.com
Description: Load blog Post on scroll.
Author: Inmaxsys Technologies
Author URI: http://inmaxsys.com
Text Domain: Lazy Loader, Auto Load
Version: 1.0

== Description ==

This plugin will auto load posts on scroll.

To use this plugin please follow the below steps.

1.) Creat a Page for listing you posts.

2.) Copy The short code [lazy-loader class="lazy-loader"][/lazy-loader] and past in to newly created page.

Thats all.. you are done...
Now if you access your newly created page is will load post on scroll... 


